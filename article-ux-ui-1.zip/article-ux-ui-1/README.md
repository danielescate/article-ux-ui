# article-ux-ui

# inspiration
Table of contents
- https://dribbble.com/shots/10429352-Landing-Page-UI-Weekly-3
- https://dribbble.com/shots/6362699-Presentation
Carousel
- https://www.microsoft.com/en-ca/
- https://smartslider3.com/layer-slider-template/
Parallax
- https://canals-amsterdam.nl/
- https://the-goonies.webflow.io/#plot
- https://toyfight.co/
